USE Wistful
GO

CREATE TABLE PlayList(
	Artist nvarchar(255),
	Song nvarchar(255),
	TargetMarket nvarchar(255)
)
GO

SELECT * FROM PlayList