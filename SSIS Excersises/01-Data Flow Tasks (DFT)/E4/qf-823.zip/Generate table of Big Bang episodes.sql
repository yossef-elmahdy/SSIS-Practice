USE Wistful
GO

CREATE TABLE BigBangEpisodes(
	SeasonNumber int NULL,
	EpisodeNumber int NULL,
	DateBroadcast date NULL,
	Title varchar(255) NULL
)

GO

-- show table
SELECT * FROM BigBangEpisodes


