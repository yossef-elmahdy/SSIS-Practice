USE Wistful
GO

CREATE TABLE FoodMusic(
	Position int NULL,
	Artist nvarchar(255) NULL,
	SongTitle nvarchar(255) NULL
) 

SELECT * FROM FoodMusic

GO


