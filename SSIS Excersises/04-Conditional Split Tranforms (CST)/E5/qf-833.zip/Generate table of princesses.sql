USE Wistful
GO

CREATE TABLE Princesses(
	Princessname nvarchar(255),
	FeministRating nvarchar(255),
	FirstAppeared int,
	Vehicle nvarchar(255)
)

GO

SELECT * FROM Princesses
